import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const ProductDetailView = () => {
    // 파라미터로 받아온 값 
    const {prdNo} = useParams();
    
    // state : Db에서 가져온 상품 정보 저장함 state
    const [prd, setPrd] = useState({
        // prdNo : '',
        prdName: '',
        prdPrice: '',
        prdCompany: '',
        prdStock: '',
        prdDate: '',
    });

    // 서버에 요청해서 데이터 받아옴
    // 받아온 값을 state에 저장
    const loadData = async () => {
        //setLoading(true);
        // const response = await axios.get('http://localhost:8080/product/productDetailView' + prdNo);
        const response = await axios.get(`http://localhost:8080/product/productDetailView/${prdNo}`);
       
        // 받아온 값으로 state에 저장
        setPrd({
            // prdNo : response.data.prdNo
            prdName:response.data.prdName,
            prdPrice:response.data.prdPrice,
            prdCompany:response.data.prdCompany,
            prdStock:response.data.prdStock,
            prdDate:response.data.prdDate
        });
        //setLoading(false);
    };


    // 렌더링 될 때마다 호출되는데
    // 한 번만 호출되도록 설정 : 빈배열([]) 사용
    useEffect(() => {
        loadData();
    }, []);    
    
    let moment = require('moment');
    let date = moment(prd.prdDate).format("YYYY-MM-DD");

    return (
        <div>
           <table border="1" width="500">
			<tr>
				<td>상품번호</td>
                <td>{prdNo}</td>
			</tr>
			<tr>
				<td>상품명</td>
                <td>{prd.prdName}</td>
			</tr>
			<tr>
				<td>가격</td>
                <td>{prd.prdPrice}</td>
			</tr>
			<tr>
				<td>제조사</td>
                <td>{prd.prdCompany}</td>
			</tr>
			<tr>
				<td>재고</td>
                <td>{prd.prdStock}</td>
			</tr>
			<tr>
				<td>제조일</td>
				<td>{date}</td>
			</tr>
		</table>
        </div>
    );
};

export default ProductDetailView;