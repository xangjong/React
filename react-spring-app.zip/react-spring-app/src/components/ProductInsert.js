import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const ProductInsert = () => {
  let history = useNavigate(); // 다른 페이지로 이동하기 위해 필요
  //state
  const [prd, setPrd] = useState({
    prdNo: "",
    prdName: "",
    prdPrice: "",
    prdCompany: "",
    prdStock: "",
    prdDate: "",
  });

  // prd에서 변수로 추출 : prd.prdNo로 사용하지 않고 바로 prdNo로 사용하기 위한 방법
  //const { prdNo, prdName, prdPrice, prdCompany, prdStock, prdDate } = prd;

  // 이벤트 처리

  // <input> 태그에 입력한 값을 state에 저장
  const onChange = (e) => {
    const { value, name } = e.target; // e.target에서 name과 value 추출

    setPrd({
      ...prd, // 기존의 prd 객체 복사한 뒤
      [name]: value, // name 키를 가진 값을 value로 설정
    });
  };

  // [취소] 버튼 툴렀을 때 값 비우기
  const onReset = () => {
    setPrd({
      prdNo: "",
      prdName: "",
      prdPrice: "",
      prdCompany: "",
      prdStock: "",
      prdDate: "",
    });
  };

  // [등록] 버튼 눌렀을 때 submit 이벤트 발생
  const onSubmit = (e) => {
    e.preventDefault();

    let frmData = new FormData(document.frmInsert);

    axios
      .post("http://localhost:8080/product/insert", frmData)
      .then((response) => {
        alert("등록 완료");
        // 상품 정보 조회 화면으로 이동 (포워딩)
        history("/productList"); // location.href 기능
      });
  };

  return (
    <div>
      <h3>상품 등록</h3>
      <form name="frmInsert" onSubmit={onSubmit} onReset={onReset}>
        <table>
          <thead>
            <tr>
              <td>상품번호</td>
              <td>
                <input
                  type="text"
                  name="prdNo"
                  value={prd.prdNo}
                  onChange={onChange}
                />
              </td>
            </tr>
            <tr>
              <td>상품명</td>
              <td>
                <input
                  type="text"
                  name="prdName"
                  value={prd.prdName}
                  onChange={onChange}
                />
              </td>
            </tr>
            <tr>
              <td>가격</td>
              <td>
                <input
                  type="text"
                  name="prdPrice"
                  value={prd.prdPrice}
                  onChange={onChange}
                />
              </td>
            </tr>
            <tr>
              <td>제조회사</td>
              <td>
                <input
                  type="text"
                  name="prdCompany"
                  value={prd.prdCompany}
                  onChange={onChange}
                />
              </td>
            </tr>
            <tr>
              <td>재고</td>
              <td>
                <input
                  type="text"
                  name="prdStock"
                  value={prd.prdStock}
                  onChange={onChange}
                />
              </td>
            </tr>
            <tr>
              <td>제조일</td>
              <td>
                <input
                  type="text"
                  name="prdDate"
                  value={prd.prdDate}
                  onChange={onChange}
                />
              </td>
            </tr>
            <tr>
              <td colSpan="2">
                <input type="submit" value="등록" />
                <input type="reset" value="취소" />
              </td>
            </tr>
          </thead>
        </table>
      </form>
    </div>
  );
};

export default ProductInsert;