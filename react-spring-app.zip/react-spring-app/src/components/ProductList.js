import React, { useState, useEffect} from 'react';
import axios from 'axios';
import ProductListItem from './ProductListItem';

const ProductList = () => {
    // state : 서버로부터 받은 값 저장
    const [data, setData] = useState([]);   // 주의! - 배열 사용
    //const [loading, setLoading] = useState(false);

    // 서버에 요청해서 데이터 받아옴
    // 받아온 값을 state에 저장
    const loadData = async () => {
        //setLoading(true);
        const response = await axios.get('http://localhost:8080/product/productList');
        console.log("response.data : ", response.data);

        // 받아온 값으로 state에 저장
        setData(response.data.prdList); // 주의! - prdList가 배열이므로 prdList까지 적는다
        //setLoading(false);
    };

    console.log("data : ", data);

    // 렌더링 될 때마다 호출되는데
    // 한 번만 호출되도록 설정 : 빈배열([]) 사용
    useEffect(() => {
        loadData();
    }, []);    

    return (
        <div>
            <h3>상품 정보 조회</h3>
            <table border="1">
                <thead>
                    <tr>
                        <th>상품번호</th>
                        <th>상품명</th>
                        <th>가격</th>
                        <th>제조회사</th>
                        <th>재고</th>
                        <th>제조일</th>
                        <th>수정</th>
                    </tr>
                </thead>
                <tbody>
                     {/* 여기에  출력 */}
                    {
                        data.map(function(prd, i) {
                            return <ProductListItem prd={prd} key={i} />;
                        })    
                    }
                </tbody>
            </table>
        </div>
    );
};

export default ProductList;