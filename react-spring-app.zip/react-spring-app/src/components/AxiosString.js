import axios from 'axios';
import React, { useEffect, useState } from 'react';

const AxiosString = () => {
    // state : 서버로부터 받은 값 저장 
    const [data, setData] = useState('');
    const [loading, setLoading] = useState(false);


    // 서버에 요청 시 데이터 받아옴
    // 받아온 값을 state에 저장
    const loadData = async () => {
        setLoading(true);
        const response = await axios.get("http://localhost:8080/hello");
        console.log(response.data);
        // 받아온 값으로 state에 저장 
        setData(response.data);
        setLoading(false);
    }

    // 렌더링 될 때마다 호출 되는데
    // 한 번만 호출하도록 설정 : 빈배열([]) 사용
   useEffect(() => {
        loadData();
   }, []);

    return (
        <div>
            <h3>서버로부터 받아온 값</h3>
            {data}
        </div>
    );
};

export default AxiosString;