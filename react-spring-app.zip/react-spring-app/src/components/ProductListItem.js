import React from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const ProductListItem = ({ prd }) => {
  let moment = require("moment");
  let date = moment(prd.prdDate).format("YYYY-MM-DD");

  let history = useNavigate(); // 다른 페이지로 이동하기 위해 필요

  const onDeleteItem = () => {
    if (window.confirm("삭제하시겠습니까?")) {
      axios
        .get("http://localhost:8080/product/delete/" + prd.prdNo)
        .then(() => {
          history("/productList"); // location.href 기능
          window.location.reload();
          // reload 하지 않으면
          // DB에서는 삭제되지만 화면은 안 봐뀜
        })
        .catch((err) => console.log(err));
    }
  };

  return (
    <tr>
      <td>
        <Link to={"/productDetailView/" + prd.prdNo}>{prd.prdNo}</Link>
      </td>
      <td>{prd.prdName}</td>
      <td>{prd.prdPrice}</td>
      <td>{prd.prdCompany}</td>
      <td>{prd.prdStock}</td>
      <td>{date}</td>
      <td>
        <Link to={"/productUpdate/" + prd.prdNo}>수정</Link>
      </td>
      <td>
        <button onClick={onDeleteItem}>삭제</button>
      </td>
    </tr>
  );
};

// const ProductListItem = (props) => {
//   return (
//     <div>
//       <tr>
//         <td>{props.prd.prdNo}</td>
//         <td>{props.prd.prdName}</td>
//         <td>{props.prd.prdPrice}</td>
//         <td>{props.prd.prdCompany}</td>
//         <td>{props.prd.prdStock}</td>
//         <td>{props.prd.prdDate}</td>
//       </tr>
//     </div>
//   );
// };

export default ProductListItem;