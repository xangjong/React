import './App.css';
import AxiosString from './components/AxiosString';
import Top from "./components/Top"

function App() {
  return (
    <div className="App">
      {/* <AxiosString></AxiosString> */}
      <Top></Top>
    </div>
  );
}

export default App;
